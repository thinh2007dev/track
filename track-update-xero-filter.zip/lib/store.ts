import { accounts as seedAccounts } from "./mock-data";
import type { BloxAccount } from "./types";

const globalStore = globalThis as unknown as { fruitVaultAccounts?: Map<string, BloxAccount> };
const accountStore = globalStore.fruitVaultAccounts ?? new Map(seedAccounts.map(account => [account.id, account]));
globalStore.fruitVaultAccounts = accountStore;

export function listAccounts() {
  const seenUsernames = new Set<string>();
  return [...accountStore.values()].filter(account => {
    const key = account.username.trim().toLowerCase();
    if (seenUsernames.has(key)) return false;
    seenUsernames.add(key);
    return true;
  });
}

export function upsertAccount(account: BloxAccount) {
  for (const [id, existing] of accountStore.entries()) {
    if (id !== account.id && existing.username.trim().toLowerCase() === account.username.trim().toLowerCase()) {
      accountStore.delete(id);
    }
  }
  accountStore.set(account.id, account);
  return account;
}
